%ve_eegplot() - Scroll (horizontally and/or vertically) through multichannel data.
%             Allows vertical scrolling through channels and manual marking 
%             and unmarking of data stretches or epochs for rejection.
% Usage: 
%           >> ve_eegplot(data, 'key1', value1 ...); % use interface buttons, etc.
%      else
%           >> ve_eegplot('noui', data, 'key1', value1 ...); % no user interface;
%                                                         % use for plotting
% Menu items:
%    "Figure > print" - [menu] Print figure in portrait or landscape.
%    "Figure > Edit figure" - [menu] Remove menus and buttons and call up the standard
%                  Matlab figure menu. Select "Tools > Edit" to format the figure
%                  for publication. Command line equivalent: 'noui' 
%    "Figure > Accept and Close" - [menu] Same as the bottom-right "Reject" button. 
%    "Figure > Cancel and Close" - [menu] Cancel all editing, same as the "Cancel" button. 
%    "Display > Marking color" > [Hide|Show] marks" - [menu] Show or hide patches of 
%                  background color behind the data. Mark stretches of *continuous* 
%                  data (e.g., for rejection) by dragging the mouse horizontally 
%                  over the activity. With *epoched* data, click on the selected epochs.
%                  Clicked on a marked region to unmark it. Called from the
%                  command line, marked data stretches or epochs are returned in 
%                  the TMPREJ variable in the global workspace *if/when* the "Reject" 
%                  button is pressed (see Outputs); called from pop_eegplot() or 
%                  eeglab(), the marked data portions are removed from the current
%                  dataset, and the dataset is automatically updated.
%     "Display > Marking color > Choose color" - [menu] Change the background marking 
%                  color. The marking color(s) of previously marked trials are preserved. 
%                  Called from command line, subsequent functions eegplot2event() or 
%                  eegplot2trials() allow processing trials marked with different colors 
%                  in the TMPREJ output variable. Command line equivalent: 'wincolor'.
%     "Display > Grid > ..." - [menu] Toggle (on or off) time and/or channel axis grids 
%                  in the activity plot. Submenus allow modifications to grid aspects.
%                  Command line equivalents: 'xgrid' / 'ygrid' 
%     "Display > Show scale" - [menu] Show (or hide if shown) the scale on the bottom 
%                  right corner of the activity window. Command line equivalent: 'scale' 
%     "Display > Title" - [menu] Change the title of the figure. Command line equivalent: 
%                  'title'
%     "Settings > Time range to display"  - [menu] For continuous EEG data, this item 
%                  pops up a query window for entering the number of seconds to display
%                  in the activity window. For epoched data, the query window asks
%                  for the number of epochs to display (this can be fractional). 
%                  Command line equivalent: 'winlength'
%     "Settings > Number of channels to display" - [menu] Number of channels to display
%                  in the activity window.  If not all channels are displayed, the 
%                  user may scroll through channels using the slider on the left 
%                  of the activity plot. Command line equivalent: 'dispchans'
%     "Settings > Channel labels > ..."  - [menu] Use numbers as channel labels or load
%                  a channel location file from disk. If called from the eeglab() menu or
%                  pop_eegplot(), the channel labels of the dataset will be used. 
%                  Command line equivalent: 'eloc_file'
%     "Settings > Zoom on/off" - [menu] Toggle Matlab figure zoom on or off for time and
%                  electrode axes. left-click to zoom (x2); right-click to reverse-zoom. 
%                  Else, draw a rectange in the activity window to zoom the display into 
%                  that region. NOTE: When zoom is on, data cannot be marked for rejection.
%     "Settings > Events" - [menu] Toggle event on or off (assuming events have been 
%                  given as input). Press "legend" to pop up a legend window for events.
%
% Display window interface:
%    "Activity plot" - [main window] This axis displays the channel activities.  For 
%                  continuous data, the time axis shows time in seconds. For epoched
%                  data, the axis label indicate time within each epoch.
%    "Cancel" - [button] Closes the window and cancels any data rejection marks.
%    "Event types" - [button] pop up a legend window for events.
%    "<<" - [button] Scroll backwards though time or epochs by one window length.
%    "<"  - [button] Scroll backwards though time or epochs by 0.2 window length.
%    "Navigation edit box" - [edit box] Enter a starting time or epoch to jump to.
%    ">"  - [button] Scroll forward though time or epochs by 0.2 window length.
%    ">>" - [button] Scroll forward though time or epochs by one window length.
%    "Chan/Time/Value" - [text] If the mouse is within the activity window, indicates
%                  which channel, time, and activity value the cursor is closest to.
%    "Scale edit box" - [edit box] Scales the displayed amplitude in activity units.
%                  Command line equivalent: 'spacing' 
%    "+ / -" - [buttons] Use these buttons to +/- the amplitude scale by 10%. 
%    "Reject" - [button] When pressed, save rejection marks and close the figure. 
%                  Optional input parameter 'command' is evaluated at that time. 
%                  NOTE: This button's label can be redefined from the command line
%                  (see 'butlabel' below). If no processing command is specified
%                  for the 'command' parameter (below), this button does not appear.
%    "Stack/Spread" - [button] "Stack" collapses all channels/activations onto the
%                  middle axis of the plot. "Spread" undoes the operation.
%    "Norm/Denorm" - [button] "Norm" normalizes each channel separately such that all
%                  channels have the same standard deviation without changing original 
%                  data/activations under EEG structure. "Denorm" undoes the operation.  
%                 
% Required command line input:
%    data        - Input data matrix, either continuous 2-D (channels,timepoints) or 
%                  epoched 3-D (channels,timepoints,epochs). If the data is preceded 
%                  by keyword 'noui', GUI control elements are omitted (useful for 
%                  plotting data for presentation). A set of power spectra at
%                  each channel may also be plotted (see 'freqlimits' below).
% Optional command line keywords:
%    'srate'      - Sampling rate in Hz {default|0: 256 Hz}
%    'spacing'    - Display range per channel (default|0: max(whole_data)-min(whole_data))
%    'eloc_file'  - Electrode filename (as in  >> topoplot example) to read
%                    ascii channel labels. Else,
%                   [vector of integers] -> Show specified channel numbers. Else,
%                   [] -> Do not show channel labels {default|0 -> Show [1:nchans]}
%    'limits'     - [start end] Time limits for data epochs in ms (for labeling 
%                   purposes only).
%    'freqlimits' - [start end] If plotting epoch spectra instead of data, frequency 
%                   limits of the display. (Data should contain spectral values).
%    'winlength'  - [value] Seconds (or epochs) of data to display in window {default: 5}
%    'dispchans'  - [integer] Number of channels to display in the activity window 
%                   {default: from data}.  If < total number of channels, a vertical  
%                   slider on the left side of the figure allows vertical data scrolling. 
%    'title'      - Figure title {default: none}
%    'xgrid'      - ['on'|'off'] Toggle display of the x-axis grid {default: 'off'}
%    'ygrid'      - ['on'|'off'] Toggle display of the y-axis grid {default: 'off'}
%    'ploteventdur' - ['on'|'off'] Toggle display of event duration { default: 'off' }
%    'data2'      - [float array] identical size to the original data and
%                   plotted on top of it.
%
% Additional keywords:
%    'command'    - ['string'] Matlab command to evaluate when the 'REJECT' button is 
%                   clicked. The 'REJECT' button is visible only if this parameter is 
%                   not empty. As explained in the "Output" section below, the variable 
%                   'TMPREJ' contains the rejected windows (see the functions 
%                   eegplot2event() and eegplot2trial()).
%    'butlabel'   - Reject button label. {default: 'REJECT'}
%    'winrej'     - [start end R G B e1 e2 e3 ...] Matrix giving data periods to mark 
%                    for rejection, each row indicating a different period
%                      [start end] = period limits (in frames from beginning of data); 
%                      [R G B] = specifies the marking color; 
%                      [e1 e2 e3 ...] = a (1,nchans) logical [0|1] vector giving 
%                         channels (1) to mark and (0) not mark for rejection.
%    'color'      - ['on'|'off'|cell array] Plot channels with different colors.
%                   If an RGB cell array {'r' 'b' 'g'}, channels will be plotted 
%                   using the cell-array color elements in cyclic order {default:'off'}. 
%    'wincolor'   - [color] Color to use to mark data stretches or epochs {default: 
%                   [ 0.7 1 0.9] is the default marking color}
%    'events'     - [struct] EEGLAB event structure (EEG.event) to use to show events.
%    'submean'    - ['on'|'off'] Remove channel means in each window {default: 'on'}
%    'position'   - [lowleft_x lowleft_y width height] Position of the figure in pixels.
%    'tag'        - [string] Matlab object tag to identify this eegplot() window (allows 
%                    keeping track of several simultaneous eegplot() windows). 
%    'children'   - [integer] Figure handle of a *dependent* eegplot() window. Scrolling
%                    horizontally in the master window will produce the same scroll in 
%                    the dependent window. Allows comparison of two concurrent datasets,
%                    or of channel and component data from the same dataset.
%    'scale'      - ['on'|'off'] Display the amplitude scale {default: 'on'}.
%    'mocap'      - ['on'|'off'] Display motion capture data in a separate figure.
%                     To run, select an EEG data period in the scolling display using 
%                     the mouse. Motion capture (mocap) data should be
%                     under EEG.moredata.mocap.markerPosition in xs, ys and zs fields which are
%                     (number of markers, number of time points) arrays.                
%                    {default: 'off'}.
%    'selectcommand' - [cell array] list of 3 commands (strings) to run when the mouse 
%                      button is down, when it is moving and when the mouse button is up.
%    'ctrlselectcommand' - [cell array] same as above in conjunction with pressing the 
%                      CTRL key.
% Outputs:
%    TMPREJ       -  Matrix (same format as 'winrej' above) placed as a variable in
%                    the global workspace (only) when the REJECT button is clicked. 
%                    The command specified in the 'command' keyword argument can use 
%                    this variable. (See eegplot2trial() and eegplot2event()). 
%
% Author: Arnaud Delorme & Colin Humphries, CNL/Salk Institute, SCCN/INC/UCSD, 1998-2001
%
% See also: eeg_multieegplot(), eegplot2event(), eegplot2trial(), eeglab()


% deprecated 
%    'colmodif'   - nested cell array of window colors that may be marked/unmarked. Default
%                   is current color only.

% Copyright (C) 2001 Arnaud Delorme & Colin Humphries, Salk Institute, arno@salk.edu
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

% Note for programmers - Internal variable structure:
% All in g. except for Eposition and Eg.spacingwhich are inside the boxes
% gcf
%    1 - winlength
%    2 - srate 
%    3 - children
% 'backeeg' axis
%    1 - trialtag
%    2 - g.winrej
%    3 - nested call flag
% 'eegaxis'
%    1 - data
%    2 - colorlist
%    3 - submean    % on or off, subtract the mean
%    4 - maxfreq    % empty [] if no gfrequency content
% 'buttons hold other informations' Eposition for instance hold the current postition

function [outvar1] = ve_eegplot(data, varargin); % p1,p2,p3,p4,p5,p6,p7,p8,p9)

% Defaults (can be re-defined):

DEFAULT_PLOT_COLOR = { [0 0 1], [0.7 0.7 0.7]};         % EEG line color
try, icadefs;
	DEFAULT_FIG_COLOR = BACKCOLOR;
	BUTTON_COLOR = GUIBUTTONCOLOR;
catch
	DEFAULT_FIG_COLOR = [1 1 1];
	BUTTON_COLOR =[0.8 0.8 0.8];
end;
DEFAULT_AXIS_COLOR = 'k';         % X-axis, Y-axis Color, text Color
DEFAULT_GRID_SPACING = 1;         % Grid lines every n seconds
DEFAULT_GRID_STYLE = '-';         % Grid line style
YAXIS_NEG = 'off';                % 'off' = positive up 
DEFAULT_NOUI_PLOT_COLOR = 'k';    % EEG line color for noui option
                                  %   0 - 1st color in AxesColorOrder
SPACING_EYE = 'on';               % g.spacingI on/off
SPACING_UNITS_STRING = '';        % '\muV' for microvolt optional units for g.spacingI Ex. uV
MAXEVENTSTRING = 10;
DEFAULT_AXES_POSITION = [0.0964286 0.15 0.842 0.75-(MAXEVENTSTRING-5)/100];
                                  % dimensions of main EEG axes
ORIGINAL_POSITION = [50 50 800 500];

%persistent ax0; 
%persistent ax1;
%persistent etime;
%persistent eelec;
%persistent evalue;

if nargin < 1
   help ve_eegplot
   return
end
				  
% %%%%%%%%%%%%%%%%%%%%%%%%
% Setup inputs
% %%%%%%%%%%%%%%%%%%%%%%%%

if ~isstr(data) % If NOT a 'noui' call or a callback from uicontrols

   %try
    options = varargin;
    for index = 1:length(options)
       if iscell(options{index}) && ~iscell(options{index}{1}) ...
           options{index} = { options{index} }; 
       end;
    end;
    g = [];
    if ~isempty( varargin )
       g = struct(options{:});
    end
  % push button: create/remove window
  % ---------------------------------
  defdowncom   = 've_eegplot(''defdowncom'',   gcbf);'; % push button: create/remove window
  defmotioncom = 've_eegplot(''defmotioncom'', gcbf);'; % motion button: move windows or display current position
  defupcom     = 've_eegplot(''defupcom'',     gcbf);';
  defctrldowncom = 've_eegplot(''topoplot'',   gcbf);'; % CTRL press and motion -> do nothing by default
  defctrlmotioncom = ''; % CTRL press and motion -> do nothing by default
  defctrlupcom = ''; % CTRL press and up -> do nothing by default

   try g.srate; 		    catch, g.srate		= 256; 	end;
   try g.spacing; 			catch, g.spacing	= 0; 	end;
   try g.eloc_file; 		catch, g.eloc_file	= 0; 	end; % 0 mean numbered
   try g.winlength; 		catch, g.winlength	= 5; 	end; % Number of seconds of EEG displayed
   try g.position; 	    catch, g.position	= ORIGINAL_POSITION; 	end;
   try g.title; 		    catch, g.title		= ['Scroll activity -- ve_eegplot()']; 	end;
   try g.trialstag; 		catch, g.trialstag	= -1; 	end;
   try g.winrej; 			catch, g.winrej		= []; 	end;
   try g.command; 			catch, g.command	= ''; 	end;
   try g.tag; 				catch, g.tag		= 've_eegplot'; end;
   try g.xgrid;		    catch, g.xgrid		= 'off'; end;
   try g.ygrid;		    catch, g.ygrid		= 'off'; end;
   try g.color;		    catch, g.color		= 'off'; end;
   try g.submean;			catch, g.submean	= 'on'; end;
   try g.children;			catch, g.children	= 0; end;
   try g.limits;		    catch, g.limits	    = [0 1000*(size(data,2)-1)/g.srate]; end;
   try g.freqlimits;	    catch, g.freqlimits	= []; end;
   try g.dispchans; 		catch, g.dispchans  = size(data,1); end;
   try g.wincolor; 		catch, g.wincolor   = [ 0.7 1 0.9]; end;
   try g.butlabel; 		catch, g.butlabel   = 'REJECT'; end;
   try g.colmodif; 		catch, g.colmodif   = { g.wincolor }; end;
   try g.scale; 		    catch, g.scale      = 'on'; end;
   try g.events; 		    catch, g.events      = []; end;
   try g.ploteventdur;     catch, g.ploteventdur = 'off'; end;
   try g.data2;            catch, g.data2      = []; end;
   if ischar(g.data2)
       g.data2 = evalin('base',g.data2);
   end
   try g.plotdata2;        catch, g.plotdata2 = 'off'; end;
   try g.mocap;		    catch, g.mocap		= 'off'; end; % nima
   try g.selectcommand;    catch, g.selectcommand     = { defdowncom defmotioncom defupcom }; end;
%   try g.ctrlselectcommand;catch, g.ctrlselectcommand = { defctrldowncom defctrlmotioncom defctrlupcom }; end;
   try g.altselectcommand; catch, g.altselectcommand = { }; end;
   try g.extselectcommand; catch, g.extselectcommand = { }; end;
   try g.keyselectcommand; catch, g.keyselectcommand = { }; end;
   try g.mouse_data_front; catch, g.mouse_data_front = 'on';end;
   try g.datastd;          catch, g.datastd = []; end; %ozgur
   try g.normed;           catch, g.normed = 0; end; %ozgur
   try g.envelope;          catch, g.envelope = 0; end;%ozgur
   try g.chaninfo;          catch, g.chaninfo = []; end;
   try g.data_type;         catch, g.data_type = []; end;
   try g.chan_marks_struct; catch, g.chan_marks_struct = []; end;
   try g.time_marks_struct; catch, g.time_marks_struct = []; end;
   try g.marks_y_loc;       catch, g.marks_y_loc = [.7]; end;
   try g.inter_mark_int;    catch, g.inter_mark_int = .01; end;
   try g.inter_tag_int;     catch, g.inter_tag_int = .002; end;
   
   if strcmpi(g.ploteventdur, 'on'), g.ploteventdur = 1; else g.ploteventdur = 0; end;
   if ndims(data) > 2
   		g.trialstag = size(	data, 2);
   	end;	
      
   gfields = fieldnames(g);
   for index=1:length(gfields)
      switch gfields{index}
      case {'spacing', 'srate' 'eloc_file' 'winlength' 'position' 'title' ...
               'trialstag'  'winrej' 'command' 'tag' 'xgrid' 'ygrid' 'color' 'colmodif'...
               'freqlimits' 'submean' 'children' 'limits' 'dispchans' 'wincolor' ...
               'ploteventdur' 'butlabel' 'scale' 'events' 'data2' 'plotdata2' 'mocap' ...
               'selectcommand' 'altselectcommand' 'extselectcommand'  'keyselectcommand'...
               'mouse_data_front' 'datastd' 'normed' 'envelope' 'chaninfo' ...
               'data_type' 'chan_marks_struct' 'time_marks_struct' ...
               'marks_y_loc' 'inter_mark_int' 'inter_tag_int' ...
               'marks_col_int' 'marks_col_alpha'},;
      otherwise, error(['ve_eegplot: unrecognized option: ''' gfields{index} '''' ]);
      end;
   end;

   % g.data=data; % never used and slows down display dramatically - Ozgur 2010
   
   if length(g.srate) > 1
   		disp('Error: srate must be a single number'); return;
   end;	
   if length(g.spacing) > 1
   		disp('Error: ''spacing'' must be a single number'); return;
   end;	
   if length(g.winlength) > 1
   		disp('Error: winlength must be a single number'); return;
   end;	
   if isstr(g.title) > 1
   		disp('Error: title must be is a string'); return;
   end;	
   if isstr(g.command) > 1
   		disp('Error: command must be is a string'); return;
   end;	
   if isstr(g.tag) > 1
   		disp('Error: tag must be is a string'); return;
   end;	
   if length(g.position) ~= 4
   		disp('Error: position must be is a 4 elements array'); return;
   end;	
   switch lower(g.xgrid)
	   case { 'on', 'off' },; 
	   otherwise disp('Error: xgrid must be either ''on'' or ''off'''); return;
   end;	
   switch lower(g.ygrid)
	   case { 'on', 'off' },; 
	   otherwise disp('Error: ygrid must be either ''on'' or ''off'''); return;
   end;	
   switch lower(g.submean)
	   case { 'on' 'off' };
	   otherwise disp('Error: submean must be either ''on'' or ''off'''); return;
   end;	
   switch lower(g.scale)
	   case { 'on' 'off' };
	   otherwise disp('Error: scale must be either ''on'' or ''off'''); return;
   end;	
   
   if ~iscell(g.color)
	   switch lower(g.color)
		case 'on', g.color = { 'k', 'm', 'c', 'b', 'g' }; 
		case 'off', g.color = { [ 0 0 0.4] };  
		otherwise 
		 disp('Error: color must be either ''on'' or ''off'' or a cell array'); 
                return;
	   end;	
   end;
   if length(g.dispchans) > size(data,1)
	   g.dispchans = size(data,1);
   end;
   if ~iscell(g.colmodif)
   		g.colmodif = { g.colmodif };
   end;
   if strcmpi(g.submean, 'on')
       g.submean = 'nan';
   end;
   
   %colmodif .. depricated
   % convert color to modify into array of float
   % -------------------------------------------
%   for index = 1:length(g.colmodif)
%        tmpcolmodif(index) = g.colmodif{index}(1) ...
%                              + g.colmodif{index}(2)*10 ...
%                              + g.colmodif{index}(3)*100;
%   end;
%   g.colmodif = tmpcolmodif;
   
   [g.chans,g.frames, tmpnb] = size(data);
   g.frames = g.frames*tmpnb;
  
  if g.spacing == 0
    maxindex = min(1000, g.frames);  
	stds = std(data(:,1:maxindex),[],2);
    g.datastd = stds;
	stds = sort(stds);
	if length(stds) > 2
		stds = mean(stds(2:end-1)); 
	else
		stds = mean(stds);
	end;	
    g.spacing = stds*3;  
    if g.spacing > 10
      g.spacing = round(g.spacing);
    end
    if g.spacing  == 0 | isnan(g.spacing)
        g.spacing = 1; % default
    end;
  end

  % set defaults
  % ------------ 
  g.incallback = 0;
  g.winstatus = 1;
  g.setelectrode  = 0;
  [g.chans,g.frames,tmpnb] = size(data);   
  g.frames = g.frames*tmpnb;
  g.nbdat = 1; % deprecated
  g.time  = 0;
  g.elecoffset = 0;
  
  % %%%%%%%%%%%%%%%%%%%%%%%%
  % Prepare figure and axes
  % %%%%%%%%%%%%%%%%%%%%%%%%
  
  figh = figure('UserData', g,... % store the settings here
      'Color',DEFAULT_FIG_COLOR, 'name', g.title,...
      'MenuBar','none','tag', g.tag ,'Position',g.position, ...
      'numbertitle', 'off', 'visible', 'off');

  pos = get(figh,'position'); % plot relative to current axes
  q = [pos(1) pos(2) 0 0];
  s = [pos(3) pos(4) pos(3) pos(4)]./100;
  clf;
      
  % Background axis
  % ---------------
%  ax0 = axes('tag','backeeg','parent',figh,...
%      'Position',DEFAULT_AXES_POSITION,...
%      'Box','off','xgrid','off', 'xaxislocation', 'top'); 
  g.ax0 = axes('tag','backeeg','parent',figh,...
      'Position',DEFAULT_AXES_POSITION,...
      'Box','off','xgrid','off', 'xaxislocation', 'top'); 
  
  % Drawing axis
  % --------------- 
  YLabels = num2str((1:g.chans)');  % Use numbers as default
  YLabels = flipud(str2mat(YLabels,' '));
  g.ax1 = axes('Position',DEFAULT_AXES_POSITION,...
      'userdata', data, ...% store the data here
      'tag','eegaxis','parent',figh,...%(when in g, slow down display)
      'Box','on','xgrid', g.xgrid,'ygrid', g.ygrid,...
      'gridlinestyle',DEFAULT_GRID_STYLE,...
      'Xlim',[0 g.winlength*g.srate],...
      'xtick',[0:g.srate*DEFAULT_GRID_SPACING:g.winlength*g.srate],...
      'Ylim',[0 (g.chans+1)*g.spacing],...
      'YTick',[0:g.spacing:g.chans*g.spacing],...
      'YTickLabel', YLabels,...
      'XTickLabel',num2str((0:DEFAULT_GRID_SPACING:g.winlength)'),...
      'TickLength',[.005 .005],...
      'Color','none',...
      'XColor',DEFAULT_AXIS_COLOR,...
      'YColor',DEFAULT_AXIS_COLOR);
  
  if isstr(g.eloc_file) | isstruct(g.eloc_file)  % Read in electrode names
      if isstruct(g.eloc_file) & length(g.eloc_file) > size(data,1)
          g.eloc_file(end) = []; % common reference channel location
      end;
      ve_eegplot('setelect', g.eloc_file, g.ax1);
  end;
  
  % %%%%%%%%%%%%%%%%%%%%%%%%%
  % Set up uicontrols
  % %%%%%%%%%%%%%%%%%%%%%%%%%

% positions of buttons
  posbut(1,:) = [ 0.0464    0.0254    0.0385    0.0339 ]; % <<
  posbut(2,:) = [ 0.0924    0.0254    0.0288    0.0339 ]; % <
  posbut(3,:) = [ 0.1924    0.0254    0.0299    0.0339 ]; % >
  posbut(4,:) = [ 0.2297    0.0254    0.0385    0.0339 ]; % >>
  posbut(5,:) = [ 0.1287    0.0203    0.0561    0.0390 ]; % Eposition
  posbut(6,:) = [ 0.4744    0.0236    0.0582    0.0390 ]; % Espacing
  posbut(7,:) = [ 0.2762    0.01    0.0582    0.0390 ]; % elec
  posbut(8,:) = [ 0.3256    0.01    0.0707    0.0390 ]; % g.time
  posbut(9,:) = [ 0.4006    0.01    0.0582    0.0390 ]; % value
  posbut(14,:) = [ 0.2762    0.05    0.0582    0.0390 ]; % elec tag
  posbut(15,:) = [ 0.3256    0.05    0.0707    0.0390 ]; % g.time tag
  posbut(16,:) = [ 0.4006    0.05    0.0582    0.0390 ]; % value tag
  posbut(10,:) = [ 0.5437    0.0458    0.0275    0.0270 ]; %
  posbut(11,:) = [ 0.5437    0.0134    0.0275    0.0270 ]; %
  posbut(12,:) = [ 0.6    0.02    0.14    0.05 ]; % cancel
  posbut(13,:) = [-0.15   0.02    0.07    0.05 ]; % cancel
  posbut(17,:) = [-0.06    0.02    0.09    0.05 ]; % events types
  posbut(20,:) = [-0.17   0.15     0.015    0.8 ]; % slider
  posbut(21,:) = [0.738    0.87    0.06      0.048];%normalize
  posbut(22,:) = [0.738    0.93    0.06      0.048];%stack channels(same offset)
  posbut(:,1) = posbut(:,1)+0.2;

% Five move buttons: << < text > >> 

  u(1) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'Position', posbut(1,:), ...
	'Tag','Pushbutton1',...
	'string','<<',...
        'Callback',['global in_callback;', ...
                'if isempty(in_callback);in_callback=1;', ...
                '    try ve_eegplot(''drawp'',1);', ...
                '        clear global in_callback;', ...
                '    catch error_struct;', ...
                '        clear global in_callback;', ...
                '        throw(error_struct);', ...
                '    end;', ...
                'else;return;end;']);
  u(2) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'Position', posbut(2,:), ...
	'Tag','Pushbutton2',...
	'string','<',...
        'Callback',['global in_callback;', ...
                'if isempty(in_callback);in_callback=1;', ...
                '    try ve_eegplot(''drawp'',2);', ...
                '        clear global in_callback;', ...
                '    catch error_struct;', ...
                '        clear global in_callback;', ...
                '        throw(error_struct);', ...
                '    end;', ...
                'else;return;end;']);
  u(5) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'BackgroundColor',[1 1 1], ...
	'Position', posbut(5,:), ...
	'Style','edit', ...
	'Tag','EPosition',...
	'string', fastif(g.trialstag(1) == -1, '0', '1'),...
	'Callback','set(gcbo,''enable'',''off'');drawnow;set(gcbo,''enable'',''on'');ve_eegplot(''drawp'',0);');
  u(3) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'Position',posbut(3,:), ...
	'Tag','Pushbutton3',...
	'string','>',...
        'Callback',['global in_callback;', ...
                'if isempty(in_callback);in_callback=1;', ...
                '    try ve_eegplot(''drawp'',3);', ...
                '        clear global in_callback;', ...
                '    catch error_struct;', ...
                '        clear global in_callback;', ...
                '        throw(error_struct);', ...
                '    end;', ...
                'else;return;end;']);
  u(4) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'Position',posbut(4,:), ...
	'Tag','Pushbutton4',...
	'string','>>',...
    'Callback',['global in_callback;', ...
            'if isempty(in_callback);in_callback=1;', ...
            '    try ve_eegplot(''drawp'',4);', ...
            '        clear global in_callback;', ...
            '    catch error_struct;', ...
            '        clear global in_callback;', ...
            '        throw(error_struct);', ...
            '    end;', ...
            'else;return;end;']);

% Text edit fields: ESpacing

  u(6) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'BackgroundColor',[1 1 1], ...
	'Position', posbut(6,:), ...
	'Style','edit', ...
	'Tag','ESpacing',...
	'string',num2str(g.spacing),...
	'Callback','set(gcbo,''enable'',''off'');drawnow;set(gcbo,''enable'',''on'');ve_eegplot(''draws'',0);');

% Slider for vertical motion
  u(20) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'Position', posbut(20,:), ...
   'Style','slider', ...
   'visible', 'off', ...
   'sliderstep', [0.9 1], ...
   'Tag','eegslider', ...
   'callback', [ 'tmpg = get(gcbf, ''userdata'');' ... 
   				'tmpg.elecoffset = get(gcbo, ''value'')*(tmpg.chans-tmpg.dispchans);' ...
               'set(gcbf, ''userdata'', tmpg);' ...
               've_eegplot(''drawp'',0);' ...
               'clear tmpg;' ], ...
   'value', 0);

% Channels, position, value and tag

  u(9) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'BackgroundColor',DEFAULT_FIG_COLOR, ...
	'Position', posbut(7,:), ...
	'Style','text', ...
	'Tag','Eelec',...
	'string',' ');
  u(10) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'BackgroundColor',DEFAULT_FIG_COLOR, ...
	'Position', posbut(8,:), ...
	'Style','text', ...
	'Tag','Etime',...
	'string','0.00');
  u(11) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'BackgroundColor',DEFAULT_FIG_COLOR, ...
	'Position',posbut(9,:), ...
	'Style','text', ...
	'Tag','Evalue',...
	'string','0.00');

  u(14)= uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'BackgroundColor',DEFAULT_FIG_COLOR, ...
	'Position', posbut(14,:), ...
	'Style','text', ...
	'Tag','Eelecname',...
	'string','Chan.');
  u(15) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'BackgroundColor',DEFAULT_FIG_COLOR, ...
	'Position', posbut(15,:), ...
	'Style','text', ...
	'Tag','Etimename',...
	'string','Time');
  u(16) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'BackgroundColor',DEFAULT_FIG_COLOR, ...
	'Position',posbut(16,:), ...
	'Style','text', ...
	'Tag','Evaluename',...
	'string','Value');

% ESpacing buttons: + -
  u(7) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'Position',posbut(10,:), ...
	'Tag','Pushbutton5',...
	'string','+',...
	'FontSize',8,...
	'Callback','ve_eegplot(''draws'',1);');
  u(8) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'Position',posbut(11,:), ...
	'Tag','Pushbutton6',...
	'string','-',...
	'FontSize',8,...
	'Callback','ve_eegplot(''draws'',2)');

  cb_normalize = ['g = get(gcbf,''userdata'');if g.normed, disp(''Denormalizing...''); else, disp(''Normalizing...''); end;'...
    'g.ax1 = findobj(''tag'',''eegaxis'',''parent'',gcbf);' ...
    'data = get(g.ax1,''UserData'');' ...
    'if isempty(g.datastd), g.datastd = std(data(:,1:min(1000,g.frames),[],2));end;'...
    'if g.normed, for i = 1:size(data,1), data(i,:,:) = data(i,:,:)*g.datastd(i);set(gcbo,''string'', ''Norm'');set(findobj(''tag'',''ESpacing'',''parent'',gcbf),''string'',num2str(g.oldspacing));end;' ...
    'else, for i = 1:size(data,1), data(i,:,:) = data(i,:,:)/g.datastd(i);end;set(gcbo,''string'', ''Denorm'');g.oldspacing = g.spacing;set(findobj(''tag'',''ESpacing'',''parent'',gcbf),''string'',''5'');end;' ...
    'g.normed = 1 - g.normed;' ...
    've_eegplot(''draws'',0);'...
    'set(gcbf,''userdata'',g);set(g.ax1,''UserData'',data);clear g.ax1 g data;' ...
    've_eegplot(''drawp'',0);' ...
    'disp(''Done.'')'];
% Button for Normalizing data
u(21) = uicontrol('Parent',figh, ...
    'Units', 'normalized', ...
    'Position',posbut(21,:), ...
    'Tag','Norm',...
    'string','Norm', 'callback', cb_normalize);

cb_envelope = ['g = get(gcbf,''userdata'');'...
    'g.envelope = ~g.envelope;' ...
    'set(gcbf,''userdata'',g);'...
    'set(gcbo,''string'',fastif(g.envelope,''Spread'',''Stack''));' ...
    've_eegplot(''drawp'',0);clear g;'];

% Button to plot envelope of data
u(22) = uicontrol('Parent',figh, ...
    'Units', 'normalized', ...
    'Position',posbut(22,:), ...
    'Tag','Envelope',...
    'string','Stack', 'callback', cb_envelope);


  if isempty(g.command) tmpcom = 'fprintf(''Rejections saved in variable TMPREJ\n'');';   
  else tmpcom = g.command;
  end;
  acceptcommand = [ 'g = get(gcbf, ''userdata'');' ... 
				    'TMPREJ = g.winrej;' ...
		  				  tmpcom ...
                    ... % 'if g.children, delete(g.children); end;' ...
                    'delete(gcbf);' ...
                    '; clear g;']; % quitting expression
  if ~isempty(g.command)
	  u(12) = uicontrol('Parent',figh, ...
						'Units', 'normalized', ...
						'Position',posbut(12,:), ...
						'Tag','Accept',...
						'string',g.butlabel, 'callback', acceptcommand);
  end;
  u(13) = uicontrol('Parent',figh, ...
	'Units', 'normalized', ...
	'Position',posbut(13,:), ...
	'string',fastif(isempty(g.command),'CLOSE', 'CANCEL'), 'callback', ...
		[	'g = get(gcbf, ''userdata'');' ... 
            ... %'if g.children, delete(g.children); end;' ... Removed by Brad for 2015a compat
			'close(gcbf);'] );

  if ~isempty(g.events)
      u(17) = uicontrol('Parent',figh, ...
                        'Units', 'normalized', ...
                        'Position',posbut(17,:), ...
                        'string', 'Event types', 'callback', 've_eegplot(''drawlegend'', gcbf)');
  end;

  for i = 1: length(u) % Matlab 2014b OS X compatibility
      if isprop(eval(['u(' num2str(i) ')']),'Style')
          set(u(i),'Units','Normalized');
      end
  end
  
  % %%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Set up uimenus
  % %%%%%%%%%%%%%%%%%%%%%%%%%%%
  
  % Figure Menu %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  m(7) = uimenu('Parent',figh,'Label','Figure');
  m(8) = uimenu('Parent',m(7),'Label','Print');
  uimenu('Parent',m(7),'Label','Edit figure', 'Callback', 've_eegplot(''noui'');');
  uimenu('Parent',m(7),'Label','Accept and close', 'Callback', acceptcommand );
  uimenu('Parent',m(7),'Label','Cancel and close', 'Callback','delete(gcbf)')
  
  % Portrait %%%%%%%%

  timestring = ['[OBJ1,FIG1] = gcbo;',...
	        'PANT1 = get(OBJ1,''parent'');',...
	        'OBJ2 = findobj(''tag'',''orient'',''parent'',PANT1);',...
		'set(OBJ2,''checked'',''off'');',...
		'set(OBJ1,''checked'',''on'');',...
		'set(FIG1,''PaperOrientation'',''portrait'');',...
		'clear OBJ1 FIG1 OBJ2 PANT1;'];
		
  uimenu('Parent',m(8),'Label','Portrait','checked',...
      'on','tag','orient','callback',timestring)
  
  % Landscape %%%%%%%
  timestring = ['[OBJ1,FIG1] = gcbo;',...
	        'PANT1 = get(OBJ1,''parent'');',...
	        'OBJ2 = findobj(''tag'',''orient'',''parent'',PANT1);',...
		'set(OBJ2,''checked'',''off'');',...
		'set(OBJ1,''checked'',''on'');',...
		'set(FIG1,''PaperOrientation'',''landscape'');',...
		'clear OBJ1 FIG1 OBJ2 PANT1;'];
  
  uimenu('Parent',m(8),'Label','Landscape','checked',...
      'off','tag','orient','callback',timestring)

  % Print command %%%%%%%
  uimenu('Parent',m(8),'Label','Print','tag','printcommand','callback',...
  		['RESULT = inputdlg2( { ''Command:'' }, ''Print'', 1,  { ''print -r72'' });' ...
		 'if size( RESULT,1 ) ~= 0' ... 
		 '  eval ( RESULT{1} );' ...
		 'end;' ...
		 'clear RESULT;' ]);
  
  % Display Menu %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  m(1) = uimenu('Parent',figh,...
      'Label','Display', 'tag', 'displaymenu');
  
  % window grid %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  % userdata = 4 cells : display yes/no, color, electrode yes/no, 
  %                      trial boundary adapt yes/no (1/0)  
  m(11) = uimenu('Parent',m(1),'Label','Data select/mark', 'tag', 'displaywin', ...
            'userdata', { 1, [0.8 1 0.8], 0, fastif( g.trialstag(1) == -1, 0, 1)});

          uimenu('Parent',m(11),'Label','Hide marks','Callback', ...
  	        ['g = get(gcbf, ''userdata'');' ...
            'if ~g.winstatus' ... 
            '  set(gcbo, ''label'', ''Hide marks'');' ...
            'else' ...
            '  set(gcbo, ''label'', ''Show marks'');' ...
            'end;' ...
            'g.winstatus = ~g.winstatus;' ...
            'set(gcbf, ''userdata'', g);' ...
            've_eegplot(''drawb''); clear g;'] )

	% color %%%%%%%%%%%%%%%%%%%%%%%%%%
    if isunix % for some reasons, does not work under Windows
        uimenu('Parent',m(11),'Label','Choose color', 'Callback', ...
               [ 'g = get(gcbf, ''userdata'');' ...
                 'g.wincolor = uisetcolor(g.wincolor);' ...
                 'set(gcbf, ''userdata'', g ); ' ...
                 'clear g;'] )
    end;

	% set channels
	%uimenu('Parent',m(11),'Label','Mark channels', 'enable', 'off', ...
    %'checked', 'off', 'Callback', ...
  	%['g = get(gcbf, ''userdata'');' ...
  	% 'g.setelectrode = ~g.setelectrode;' ...
  	% 'set(gcbf, ''userdata'', g); ' ...
    % 'if ~g.setelectrode setgcbo, ''checked'', ''on''); ...
    % else set(gcbo, ''checked'', ''off''); end;'...
    % ' clear g;'] )

	% trials boundaries
	%uimenu('Parent',m(11),'Label','Trial boundaries', 'checked', fastif( g.trialstag(1) == -1, 'off', 'on'), 'Callback', ...
  	%['hh = findobj(''tag'',''displaywin'',''parent'', findobj(''tag'',''displaymenu'',''parent'', gcbf ));' ...
  	% 'hhdat = get(hh, ''userdata'');' ...
  	% 'set(hh, ''userdata'', { hhdat{1},  hhdat{2}, hhdat{3}, ~hhdat{4}} ); ' ...
    %'if ~hhdat{4} set(gcbo, ''checked'', ''on''); else set(gcbo, ''checked'', ''off''); end;' ... 
    %' clear hh hhdat;'] )

  % plot durations
  % --------------
  if g.ploteventdur && isfield(g.events, 'duration')
      disp(['Use menu "Display > Hide event duration" to hide colored regions ' ...
           'representing event duration']);
  end;
  if isfield(g.events, 'duration')
      uimenu('Parent',m(1),'Label',fastif(g.ploteventdur, 'Hide event duration', 'Plot event duration'),'Callback', ...
             ['g = get(gcbf, ''userdata'');' ...
              'if ~g.ploteventdur' ... 
              '  set(gcbo, ''label'', ''Hide event duration'');' ...
              'else' ...
              '  set(gcbo, ''label'', ''Show event duration'');' ...
              'end;' ...
              'g.ploteventdur = ~g.ploteventdur;' ...
              'set(gcbf, ''userdata'', g);' ...
              've_eegplot(''drawb''); clear g;'] )
  end;

  % X grid %%%%%%%%%%%%
  m(3) = uimenu('Parent',m(1),'Label','Grid');
  timestring = ['FIGH = gcbf;',...
	            'AXESH = findobj(''tag'',''eegaxis'',''parent'',FIGH);',...
	            'if size(get(AXESH,''xgrid''),2) == 2' ... %on
		        '  set(AXESH,''xgrid'',''off'');',...
		        '  set(gcbo,''label'',''X grid on'');',...
		        'else' ...
		        '  set(AXESH,''xgrid'',''on'');',...
		        '  set(gcbo,''label'',''X grid off'');',...
		        'end;' ...
		        'clear FIGH AXESH;' ];
  uimenu('Parent',m(3),'Label',fastif(strcmp(g.xgrid, 'off'), ...
         'X grid on','X grid off'), 'Callback',timestring)
  
  % Y grid %%%%%%%%%%%%%
  timestring = ['FIGH = gcbf;',...
	            'AXESH = findobj(''tag'',''eegaxis'',''parent'',FIGH);',...
	            'if size(get(AXESH,''ygrid''),2) == 2' ... %on
		        '  set(AXESH,''ygrid'',''off'');',...
		        '  set(gcbo,''label'',''Y grid on'');',...
		        'else' ...
		        '  set(AXESH,''ygrid'',''on'');',...
		        '  set(gcbo,''label'',''Y grid off'');',...
		        'end;' ...
		        'clear FIGH AXESH;' ];
  uimenu('Parent',m(3),'Label',fastif(strcmp(g.ygrid, 'off'), ...
         'Y grid on','Y grid off'), 'Callback',timestring)

  % Grid Style %%%%%%%%%
  m(5) = uimenu('Parent',m(3),'Label','Grid Style');
  timestring = ['FIGH = gcbf;',...
	        'AXESH = findobj(''tag'',''eegaxis'',''parent'',FIGH);',...
		'set(AXESH,''gridlinestyle'',''--'');',...
		'clear FIGH AXESH;'];
  uimenu('Parent',m(5),'Label','- -','Callback',timestring)
  timestring = ['FIGH = gcbf;',...
	        'AXESH = findobj(''tag'',''eegaxis'',''parent'',FIGH);',...
		'set(AXESH,''gridlinestyle'',''-.'');',...
		'clear FIGH AXESH;'];
  uimenu('Parent',m(5),'Label','_ .','Callback',timestring)
  timestring = ['FIGH = gcbf;',...
	        'AXESH = findobj(''tag'',''eegaxis'',''parent'',FIGH);',...
		'set(AXESH,''gridlinestyle'','':'');',...
		'clear FIGH AXESH;'];
  uimenu('Parent',m(5),'Label','. .','Callback',timestring)
  timestring = ['FIGH = gcbf;',...
	        'AXESH = findobj(''tag'',''eegaxis'',''parent'',FIGH);',...
		'set(AXESH,''gridlinestyle'',''-'');',...
		'clear FIGH AXESH;'];
  uimenu('Parent',m(5),'Label','__','Callback',timestring)
  
  % Submean menu %%%%%%%%%%%%%
  cb =       ['g = get(gcbf, ''userdata'');' ...
              'if strcmpi(g.submean, ''on''),' ... 
              '  set(gcbo, ''label'', ''Remove DC offset'');' ...
              '  g.submean =''off'';' ...
              'else' ...
              '  set(gcbo, ''label'', ''Do not remove DC offset'');' ...
              '  g.submean =''on'';' ...
              'end;' ...
              'set(gcbf, ''userdata'', g);' ...
              've_eegplot(''drawp'', 0); clear g;'];
  uimenu('Parent',m(1),'Label',fastif(strcmp(g.submean, 'on'), ...
         'Do not remove DC offset','Remove DC offset'), 'Callback',cb)

  % Scale Eye %%%%%%%%%
  timestring = ['[OBJ1,FIG1] = gcbo;',...
	        've_eegplot(''scaleeye'',OBJ1,FIG1);',...
		'clear OBJ1 FIG1;'];
  m(7) = uimenu('Parent',m(1),'Label','Show scale','Callback',timestring);
  
  % Title %%%%%%%%%%%%
  uimenu('Parent',m(1),'Label','Title','Callback','ve_eegplot(''title'')')
  
  % Settings Menu %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  m(2) = uimenu('Parent',figh,...
      'Label','Settings'); 
  
  % Window %%%%%%%%%%%%
  uimenu('Parent',m(2),'Label','Time range to display',...
      'Callback','ve_eegplot(''window'')')
  
  % Electrode window %%%%%%%%
  uimenu('Parent',m(2),'Label','Number of channels to display',...
      'Callback','ve_eegplot(''winelec'')')
  
  % Electrodes %%%%%%%%
  m(6) = uimenu('Parent',m(2),'Label','Channel labels');
  
  timestring = ['FIGH = gcbf;',...
	        'AXESH = findobj(''tag'',''eegaxis'',''parent'',FIGH);',...
		'YTICK = get(AXESH,''YTick'');',...
		'YTICK = length(YTICK);',...
		'set(AXESH,''YTickLabel'',flipud(str2mat(num2str((1:YTICK-1)''),'' '')));',...
		'clear FIGH AXESH YTICK;'];
  uimenu('Parent',m(6),'Label','Show number','Callback',timestring)
  uimenu('Parent',m(6),'Label','Load .loc(s) file',...
      'Callback','ve_eegplot(''loadelect'');')
  
  % Zooms %%%%%%%%
  zm = uimenu('Parent',m(2),'Label','Zoom off/on');
  commandzoom = [ 'set(gcbf, ''windowbuttondownfcn'', [ ''zoom(gcbf,''''down''''); ve_eegplot(''''zoom'''', gcbf, 1);'' ]);' ...
                  'tmpg = get(gcbf, ''userdata'');' ...
                  'set(gcbf, ''windowbuttonmotionfcn'', tmpg.commandselect{2}); clear tmpg tmpstr;'];
    
  %uimenu('Parent',zm,'Label','Zoom time', 'callback', ...
  %             [ 'zoom(gcbf, ''xon'');' commandzoom ]);
  %uimenu('Parent',zm,'Label','Zoom channels', 'callback', ...
  %             [ 'zoom(gcbf, ''yon'');' commandzoom ]);
  uimenu('Parent',zm,'Label','Zoom on', 'callback', commandzoom);
  uimenu('Parent',zm,'Label','Zoom off', 'separator', 'on', 'callback', ...
     ['zoom(gcbf, ''off''); tmpg = get(gcbf, ''userdata'');' ...
     'set(gcbf, ''windowbuttondownfcn'', tmpg.commandselect{1});' ...
     'set(gcbf, ''windowbuttonmotionfcn'', tmpg.commandselect{2});' ...
     'set(gcbf, ''windowbuttonupfcn'', tmpg.commandselect{3});' ...
     'clear tmpg;' ]);
  uimenu('Parent',figh,'Label', 'Help', 'callback', 'pophelp(''ve_eegplot'');');

  % Events %%%%%%%%
  zm = uimenu('Parent',m(2),'Label','Events');
  complotevent = [ 'tmpg = get(gcbf, ''userdata'');' ...
                  'tmpg.plotevent = ''on'';' ...                  
                  'set(gcbf, ''userdata'', tmpg); clear tmpg; ve_eegplot(''drawp'', 0);'];
  comnoevent   = [ 'tmpg = get(gcbf, ''userdata'');' ...
                  'tmpg.plotevent = ''off'';' ...                  
                  'set(gcbf, ''userdata'', tmpg); clear tmpg; ve_eegplot(''drawp'', 0);'];
  comeventleg  = [ 've_eegplot(''drawlegend'', gcbf);'];
    
  uimenu('Parent',zm,'Label','Events on'    , 'callback', complotevent, 'enable', fastif(isempty(g.events), 'off', 'on'));
  uimenu('Parent',zm,'Label','Events off'   , 'callback', comnoevent  , 'enable', fastif(isempty(g.events), 'off', 'on'));
  uimenu('Parent',zm,'Label','Events'' legend', 'callback', comeventleg , 'enable', fastif(isempty(g.events), 'off', 'on'));
  

  % %%%%%%%%%%%%%%%%%
  % Set up autoselect
  % %%%%%%%%%%%%%%%%%
  g.commandselect{1} = [ 'if strcmp(get(gcbf, ''SelectionType''),''alt''),'         g.altselectcommand{1} ...
                         'elseif strcmp(get(gcbf, ''SelectionType''),''extend''),'  g.extselectcommand{1} ...
                         'else '                                                    g.selectcommand{1} 'end;' ];
  g.commandselect{2} = [ 'if strcmp(get(gcbf, ''SelectionType''),''alt''),'         g.altselectcommand{2} ...
                         'elseif strcmp(get(gcbf, ''SelectionType''),''extend''),'  g.extselectcommand{2} ...
                         'else '                                                    g.selectcommand{2} 'end;' ];
  g.commandselect{3} = [ 'if strcmp(get(gcbf, ''SelectionType''),''alt''),'         g.altselectcommand{3} ...
                         'elseif strcmp(get(gcbf, ''SelectionType''),''extend''),'  g.extselectcommand{3} ...
                         'else '                                                    g.selectcommand{3} 'end;' ];
       
  set(figh, 'windowbuttondownfcn',   g.commandselect{1});
  set(figh, 'windowbuttonmotionfcn', g.commandselect{2});
  set(figh, 'windowbuttonupfcn',     g.commandselect{3});
  set(figh, 'interruptible', 'off');
  set(figh, 'busyaction', 'cancel');
  
  g.keycommandselect='';
  if ~isempty(g.keyselectcommand{1})
      for i=1:length(g.keyselectcommand);
          if ~isempty(g.keyselectcommand{i})
              c_pnts=strfind(g.keyselectcommand{i},',');
              g.keycommandselect = [g.keycommandselect,...
                  'if strcmp(get(gcbf,''CurrentCharacter''),''', ...
                  strtrim(g.keyselectcommand{i}(1:c_pnts(1)-1)), ...
                  '''),', ...
                  strtrim(g.keyselectcommand{i}(c_pnts(1)+1:end)), ...
                  ';end;'];
          end
      end
  end
  set(figh, 'windowkeypressfcn',   g.keycommandselect);
  set(figh, 'interruptible', 'off');
  set(figh, 'busyaction', 'cancel');
  
  % prepare event array if any
  % --------------------------
  if ~isempty(g.events)
      if ~isfield(g.events, 'type') | ~isfield(g.events, 'latency'), g.events = []; end;
  end;
      
  if ~isempty(g.events)
      if isstr(g.events(1).type)
           [g.eventtypes tmpind indexcolor] = unique({g.events.type}); % indexcolor countinas the event type
      else [g.eventtypes tmpind indexcolor] = unique([ g.events.type ]);
      end;
      g.eventcolors     = { 'r', [0 0.8 0], 'm', 'c', 'k', 'b', [0 0.8 0] };  
      g.eventstyle      = { '-' '-' '-'  '-'  '-' '-' '-' '--' '--' '--'  '--' '--' '--' '--'};
      g.eventwidths     = [ 2.5 1 ];
      g.eventtypecolors = g.eventcolors(mod([1:length(g.eventtypes)]-1 ,length(g.eventcolors))+1);
      g.eventcolors     = g.eventcolors(mod(indexcolor-1               ,length(g.eventcolors))+1);
      g.eventtypestyle  = g.eventstyle (mod([1:length(g.eventtypes)]-1 ,length(g.eventstyle))+1);
      g.eventstyle      = g.eventstyle (mod(indexcolor-1               ,length(g.eventstyle))+1);
      
      % for width, only boundary events have width 2 (for the line)
      % -----------------------------------------------------------
      indexwidth = ones(1,length(g.eventtypes))*2;
      if iscell(g.eventtypes)
          for index = 1:length(g.eventtypes)
              if strcmpi(g.eventtypes{index}, 'boundary'), indexwidth(index) = 1; end;
          end;
      end;
      g.eventtypewidths = g.eventwidths (mod(indexwidth([1:length(g.eventtypes)])-1 ,length(g.eventwidths))+1);
      g.eventwidths     = g.eventwidths (mod(indexwidth(indexcolor)-1               ,length(g.eventwidths))+1);
      
      % latency and duration of events
      % ------------------------------
      g.eventlatencies  = [ g.events.latency ]+1;
      if isfield(g.events, 'duration')
           g.eventlatencyend   = g.eventlatencies + double([g.events.duration])+1;
      else g.eventlatencyend   = [];
      end;
      g.plotevent       = 'on';
  end;
  if isempty(g.events)
      g.plotevent      = 'off';
  end;

  set(figh, 'userdata', g);
  
  % %%%%%%%%%%%%%%%%%%%%%%%%%%
  % Plot EEG Data
  % %%%%%%%%%%%%%%%%%%%%%%%%%%
  axes(g.ax1)
  hold on
  
  % %%%%%%%%%%%%%%%%%%%%%%%%%%
  % Plot Spacing I
  % %%%%%%%%%%%%%%%%%%%%%%%%%%
  YLim = get(g.ax1,'Ylim');
  A = DEFAULT_AXES_POSITION;
  axes('Position',[A(1)+A(3) A(2) 1-A(1)-A(3) A(4)],'Visible','off','Ylim',YLim,'tag','eyeaxes')
  axis manual
  if strcmp(SPACING_EYE,'on'),  set(m(7),'checked','on')
  else set(m(7),'checked','off');
  end 
  ve_eegplot('scaleeye', [], gcf);
  if strcmp(lower(g.scale), 'off')
	  ve_eegplot('scaleeye', 'off', gcf);
  end;
  
  ve_eegplot('drawp', 0);
  %ve_eegplot('drawp', 0);
  if g.dispchans ~= g.chans
  	   ve_eegplot('zoom', gcf);
  end;  
  ve_eegplot('scaleeye', [], gcf);
  
  h = findobj(gcf, 'style', 'pushbutton');
  set(h, 'backgroundcolor', BUTTON_COLOR);
  h = findobj(gcf, 'tag', 'eegslider');
  set(h, 'backgroundcolor', BUTTON_COLOR);
  set(figh, 'visible', 'on');
  
  if ~isfield(g,'etime');
    g.etime = findobj('tag','Etime','parent',figh);
  end;
  if ~isfield(g,'eelec');
    g.eelec = findobj('tag','Eelec','parent',figh);
  end;
  if ~isfield(g,'evalue');
    g.evalue = findobj('tag','Evalue','parent',figh);
  end;
  
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End Main Function
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

else
  try p1 = varargin{1}; p2 = varargin{2}; p3 = varargin{3}; catch, end;
  switch data
  case 'drawp' % Redraw EEG and change position

    % this test help to couple ve_eegplot windows
    if exist('p3')
    	figh = p3;
    	figure(p3);
    else	
    	figh = gcf;                          % figure handle
	end;
    if strcmp(get(figh,'tag'),'dialog')
      figh = get(figh,'UserData');
    end
    g = get(figh,'UserData');
    data = get(g.ax1,'UserData');
    ESpacing = findobj('tag','ESpacing','parent',figh);   % ui handle
    EPosition = findobj('tag','EPosition','parent',figh); % ui handle
    if g.trialstag(1) == -1
        g.time    = str2num(get(EPosition,'string'));  
    else
        g.time    = str2num(get(EPosition,'string'));
        g.time    = g.time - 1;
    end; 
    g.spacing = str2num(get(ESpacing,'string'));
        
    switch p1
    case 1
        % << subtract one window length
        g.time = g.time-g.winlength;
    case 2
        % < subtract one second
        g.time = g.time-fastif(g.winlength>=1, 1, g.winlength/5);
    case 3
        % > add one second
        g.time = g.time+fastif(g.winlength>=1, 1, g.winlength/5);
    case 4
        % >> add one window length
        g.time = g.time+g.winlength;
    end
    
	 if g.trialstag ~= -1 % time in second or in trials
		multiplier = g.trialstag;	
	 else
		multiplier = g.srate;
	 end;		
    
    % Update edit box
    % ---------------
    g.time = max(0,min(g.time,ceil((g.frames-1)/multiplier)-g.winlength));
    if g.trialstag(1) == -1
        set(EPosition,'string',num2str(g.time)); 
    else 
        set(EPosition,'string',num2str(g.time+1)); 
    end; 
    set(figh, 'userdata', g);

    lowlim = round(g.time*multiplier+1);
    highlim = round(min((g.time+g.winlength)*multiplier+2,g.frames));
    low_high_range = lowlim:highlim;
    %zlowhigh = zeros(1,length(low_high_range));
    
    % Plot data and update axes
    % -------------------------
    if ~isempty(g.data2)
        switch lower(g.submean) % subtract the mean ?
         case 'on', 
          meandata = mean(g.data2(:,lowlim:highlim)');  
          if any(isnan(memdata))
              meandata = nan_mean(g.data2(:,lowlim:highlim)');
          end;
         otherwise, meandata = zeros(1,g.chans);
        end;
    else
        switch lower(g.submean) % subtract the mean ?
         case 'on', 
          meandata = mean(data(:,lowlim:highlim)');
          if any(isnan(meandata))
              meandata = nan_mean(data(:,lowlim:highlim)');
          end;
         otherwise, meandata = zeros(1,g.chans);
        end;
    end;
    if strcmpi(g.plotdata2, 'off')
        axes(g.ax1)
        obj_2_clear = findobj('-regexp','tag','text_*','-or','-regexp','tag','marker_*');
        cla(obj_2_clear); % clear all except text and markers
    end;
    
    oldspacing = g.spacing;
    if g.envelope
        g.spacing = 0;
    end
    % plot data
    % ---------
    axes(g.ax1)
    hold on

    g.spacing = oldspacing;
    set(g.ax1, 'Xlim',[1 g.winlength*multiplier+1],...
        'XTick',[1:multiplier*DEFAULT_GRID_SPACING:g.winlength*multiplier+1]);
    set(g.ax1, 'XTickLabel', num2str((g.time:DEFAULT_GRID_SPACING:g.time+g.winlength)'))
    
    
    %% HANDLE MARKING ...

    % get the y axis limits.
    ylims=get(gca,'YLim');

    % calculate x interval for channel tags...
    figdim=axis;
    tag_x_int=figdim(2)*g.inter_tag_int;
    
    
    % PLOT CHANNELS WHOSE ORDER IS < 0.
    
    % get the 'manual' channel mark index (should always be 1).
    manual_mark_ind=find(strcmp('manual',{g.chan_marks_struct.label}));
    % get the indexes of channel marks whose order is smaller than 0.
    mark_inds=find([g.chan_marks_struct.order]<100);
    % get the number of channel marks whose order is smaller than 0.
    n_mark_inds=length(mark_inds);
    % get the totla number of channel marks.
    tot_marks = length(g.chan_marks_struct);
    
    
    % loop through for each channel mark
    for fi=1:tot_marks;
        % get the channel indexes flagged by the current (order < 0) mark.
        chan_inds=find(g.chan_marks_struct(mark_inds(fi)).flags);
        % get the color of the current mark.
        tmp_color=g.chan_marks_struct(mark_inds(fi)).line_color;
        % if the data are overlayed.
        if strcmp(g.plotdata2, 'on');
            if length(g.color)==2;
                tmp_color=g.color{2};
            else
                tmp_color=[.7 .7 .7];
            end
        end
        % establish the x location of the current mark ticks.
        plot_p1 = 1+tag_x_int*(tot_marks-(mark_inds(fi)-1));
        % establish the y location of the current mark ticks.
        plot_p2 = (g.chans-(chan_inds-1))*g.spacing;
        % get the color of the current mark tick.
        plot_colour = g.chan_marks_struct(mark_inds(fi)).tag_color;
        
        if isempty(findobj(gcf,'tag',['tagtext_' g.chan_marks_struct(fi).label]));
            text(figdim(1)-(.01*figdim(2)-figdim(1))*fi,ylims(2)-0.005,['> ',g.chan_marks_struct(mark_inds(fi)).label], ...
                'color',plot_colour, ...
                'interpreter','none', ...
                'tag',['tagtext_' g.chan_marks_struct(fi).label], ...
                'rotation',90);
        end
%        tmph2 = text([tmplat], ylims(2)-0.005, [EVENTFONT evntxt], ...
%            'color', g.eventcolors{ event2plot(index) }, ...
%            'horizontalalignment', 'left',...
%            'rotation',90);
                
        % loop through each of the current mark channels.
        for ci=1:length(chan_inds);
            %plot tick...
            plot(plot_p1, plot_p2(ci),'<', ...
                'MarkerEdgeColor', plot_colour, ...
                'MarkerFaceColor', plot_colour, ...
                'MarkerSize', 8,'tag',['marker_' num2str(chan_inds(ci)) '_' g.chan_marks_struct(mark_inds(fi)).label]);
            
            % if this is the manual mark.. or it is another mark (order <
            % 0) that is not flagged as 'manual'.
            if fi==manual_mark_ind || ~g.chan_marks_struct(manual_mark_ind).flags(chan_inds(ci));
                % establish y index of current channel plot.
                tmp_offset=(g.chans-(chan_inds(ci)-1))*g.spacing-(meandata(chan_inds(ci)));
                % plot the line for the current mark and channel.
                line(1:length(low_high_range), ...
                data(chan_inds(ci),low_high_range) + tmp_offset, zeros(1,length(low_high_range))+g.chan_marks_struct(fi).order, ...
                'color', tmp_color, 'clipping','on','tag',['line_' num2str(chan_inds(ci))]);
            end
        end
    end
    
    % get index for all non-flagged channels.
    chan_inds=find(sum([g.chan_marks_struct.flags],2)==0);
    % set the color of non-flagged channels. 
    tmp_color=g.color{:};%[0,0,.3];
    % if there is overlayed data.
    if strcmp(g.plotdata2, 'on')
        if length(g.color)==2
            tmp_color=g.color{2};
        else
            tmp_color=[.7 .7 .7];
        end
    end
    % loop through for each of the non flagged channels.
    for ci=1:length(chan_inds);
        tmp_offset=(g.chans-(chan_inds(ci)-1))*g.spacing-(meandata(chan_inds(ci)));
        line(1:length(low_high_range), ...
            data(chan_inds(ci),low_high_range) + tmp_offset, zeros(1,length(low_high_range))+1, ...
            'color', tmp_color, 'clipping','on','tag',['line_' num2str(chan_inds(ci))]);
    end

    
    % PLOT TIME MARKS.
    
    % establish the inter mark interval.
    inter_time_mark_offset=diff(ylims)*g.inter_mark_int;
    % establish the y index of of the time marks.
    time_marks_offset=diff(ylims)*g.marks_y_loc;
    
    % plot time_info flags.
    cmap=[];  
    j=0;
    
    % loop through each time mark.
    for tmi=1:length(g.time_marks_struct);
        
        % make a two row flag array.
        cflags=double([g.time_marks_struct(tmi).flags(lowlim:highlim);g.time_marks_struct(tmi).flags(lowlim:highlim)]);
        %cdat=cflags;
        
        % scale values of flags according to marks_col_int.
        cdat=g.marks_col_int*round(cflags/g.marks_col_int);
        
        %build the color map for the current time mark.
        tmp_cdat=cdat;
        uval=unique(cdat);
        for ci=1:length(uval);
            tmp_cdat(find(cdat==uval(ci)))=ci+j-1;
            cmap(ci+j,:)=ones(1,3)-((ones(1,3)-g.time_marks_struct(tmi).color)*uval(ci));
        end
        j=j+length(uval);
        cdat=tmp_cdat;
        
        % loop through each of the time mark offsets.
        for i=1:length(time_marks_offset)
            
            % plot the surface of the current time mark.
            sh=surf(1:size(cflags,2), ...
                [ylims(1)+inter_time_mark_offset*tmi+(time_marks_offset(i))-(inter_time_mark_offset*length(g.time_marks_struct)), ...
                ylims(1)+inter_time_mark_offset*tmi+(time_marks_offset(i))+inter_time_mark_offset-(inter_time_mark_offset*length(g.time_marks_struct))], ...
                cflags, ...
                'CData',cdat, ...
                'LineStyle','none','tag',['mark_' g.time_marks_struct(tmi).label]);
            alpha(sh,g.marks_col_alpha);
            
            % add the label of the current time mark (if object empty).
            if isempty(findobj(gcf,'tag',['text_' g.time_marks_struct(tmi).label]));
                text(figdim(2), ...
                    ylims(1)+(inter_time_mark_offset*.5)+inter_time_mark_offset*tmi+(time_marks_offset(i))-(inter_time_mark_offset*length(g.time_marks_struct)), ...
                    ['> ',g.time_marks_struct(tmi).label], ...
                    'color',g.time_marks_struct(tmi).color, ...
                    'interpreter','none', ...
                    'tag',['text_' g.time_marks_struct(tmi).label]);
            end
        end
    end
    % apply the color map.
    colormap(cmap); 
    
        
    % draw selected channels (highlights channels marked in winrej period)
    % ------------------------
    if ~isempty(g.winrej) && size(g.winrej,2) > 2
        for tpmi = 1:size(g.winrej,1) % scan rows
            if (g.winrej(tpmi,1) >= lowlim && g.winrej(tpmi,1) <= highlim) || ...
                    (g.winrej(tpmi,2) >= lowlim && g.winrej(tpmi,2) <= highlim)
                abscmin = max(1,round(g.winrej(tpmi,1)-lowlim));
                abscmax = round(g.winrej(tpmi,2)-lowlim);
                maxXlim = get(gca, 'xlim');
                abscmax = min(abscmax, round(maxXlim(2)-1));
                for i = 1:g.chans
                    if g.winrej(tpmi,g.chans-i+1+5)
                        plot(abscmin+1:abscmax+1,data(g.chans-i+1,abscmin+lowlim:abscmax+lowlim) ...
                            -meandata(g.chans-i+1)+i*g.spacing + (g.dispchans+1)*(oldspacing-g.spacing)/2 +g.elecoffset*(oldspacing-g.spacing), 'color','r','clipping','on')
                    end
                end
            end
        end
    end
%    g.spacing = oldspacing;
%    set(g.ax1, 'Xlim',[1 g.winlength*multiplier+1],...
%		     'XTick',[1:multiplier*DEFAULT_GRID_SPACING:g.winlength*multiplier+1]);
%    set(g.ax1, 'XTickLabel', num2str((g.time:DEFAULT_GRID_SPACING:g.time+g.winlength)'))

    % ordinates: even if all elec are plotted, some may be hidden
    set(g.ax1, 'ylim',[g.elecoffset*g.spacing (g.elecoffset+g.dispchans+1)*g.spacing] );
	
     % draw second data if necessary
     if ~isempty(g.data2)
         tmpdata = data;
         set(g.ax1, 'userdata', g.data2);
         g.data2 = [];
         g.plotdata2 = 'on';
         set(figh, 'userdata', g);
         ve_eegplot('drawp', 0);
         g.plotdata2 = 'off';
         g.data2 = get(g.ax1, 'userdata');
         set(g.ax1, 'userdata', tmpdata);
         set(figh, 'userdata', g);
     else 
         ve_eegplot('drawb');
     end;

     if g.children ~= 0
		if ~exist('p2')
			p2 =[];
		end;	
		ve_eegplot( 'drawp', p1, p2, g.children);
		figure(figh);
	 end;	  


  case 'drawb' % Draw background ******************************************************
    % Redraw EEG and change position

    g = get(gcf,'UserData');  % Data (Note: this could also be global)

    % Plot data and update axes
    axes(g.ax0);
	cla;
	hold on;
	% plot rejected windows
	if g.trialstag ~= -1
		multiplier = g.trialstag;	
	else
		multiplier = g.srate;
	end;		

    % draw rejection windows
    % ----------------------   	
    lowlim = round(g.time*multiplier+1);
   	highlim = round(min((g.time+g.winlength)*multiplier+1));
  	displaymenu = findobj('tag','displaymenu','parent',gcf);
    if ~isempty(g.winrej) && g.winstatus
        if g.trialstag ~= -1 % epoched data
            indices = find((g.winrej(:,1)' >= lowlim & g.winrej(:,1)' <= highlim) | ...
                (g.winrej(:,2)' >= lowlim & g.winrej(:,2)' <= highlim));
            if ~isempty(indices)
                tmpwins1 = g.winrej(indices,1)';
                tmpwins2 = g.winrej(indices,2)';
                if size(g.winrej,2) > 2
                    tmpcols  = g.winrej(indices,3:5);
                else tmpcols  = g.wincolor;
                end;
                try
                    eval('[cumul indicescount] = histc(tmpwins1, (min(tmpwins1)-1):g.trialstag:max(tmpwins2));');
                catch
                    [cumul indicescount] = myhistc(tmpwins1, (min(tmpwins1)-1):g.trialstag:max(tmpwins2));
                end;
                count = zeros(size(cumul));
                %if ~isempty(find(cumul > 1)), find(cumul > 1), end;
                for tmpi = 1:length(tmpwins1)
                    poscumul = indicescount(tmpi);
                    heightbeg = count(poscumul)/cumul(poscumul);
                    heightend = heightbeg + 1/cumul(poscumul);
                    count(poscumul) = count(poscumul)+1;
                    h = patch([tmpwins1(tmpi)-lowlim tmpwins2(tmpi)-lowlim ...
                        tmpwins2(tmpi)-lowlim tmpwins1(tmpi)-lowlim], ...
                        [heightbeg heightbeg heightend heightend], ...
                        tmpcols(tmpi,:));  % this argument is color
                    set(h, 'EdgeColor', get(h, 'facecolor'))
                end;
            end;
        else
            event2plot1 = find ( g.winrej(:,1) >= lowlim & g.winrej(:,1) <= highlim );
            event2plot2 = find ( g.winrej(:,2) >= lowlim & g.winrej(:,2) <= highlim );
            event2plot3 = find ( g.winrej(:,1) <  lowlim & g.winrej(:,2) >  highlim );
            event2plot  = union(union(event2plot1, event2plot2), event2plot3);
            
            for tpmi = event2plot(:)'
                if size(g.winrej,2) > 2
                    tmpcols  = g.winrej(tpmi,3:5);
                else tmpcols  = g.wincolor;
                end;
                h = patch([g.winrej(tpmi,1)-lowlim g.winrej(tpmi,2)-lowlim ...
                    g.winrej(tpmi,2)-lowlim g.winrej(tpmi,1)-lowlim], ...
                        [0 0 1 1], tmpcols);
                set(h, 'EdgeColor', get(h, 'facecolor'))
            end;
        end;
    end;
    		
	% plot tags
	% ---------
    %if trialtag(1) ~= -1 & displaystatus % put tags at arbitrary places
    % 	for tmptag = trialtag
	%		if tmptag >= lowlim & tmptag <= highlim
	%			plot([tmptag-lowlim tmptag-lowlim], [0 1], 'b--');
   	%		end;	
    %	end;
    %end;

    % draw events if any
    % ------------------
    ylims = ylim();
    if strcmpi(g.plotevent, 'on')
        
        % find event to plot
        % ------------------
        event2plot    = find ( g.eventlatencies >=lowlim & g.eventlatencies <= highlim );
        if ~isempty(g.eventlatencyend)            
            event2plot2 = find ( g.eventlatencyend >= lowlim & g.eventlatencyend <= highlim );
            event2plot3 = find ( g.eventlatencies  <  lowlim & g.eventlatencyend >  highlim );
            event2plot  = union(union(event2plot, event2plot2), event2plot3);
        end;
        for index = 1:length(event2plot)
            % draw latency line
            % -----------------
            tmplat = g.eventlatencies(event2plot(index))-lowlim-1;
            tmph   = line([ tmplat tmplat ], ylims,'color', g.eventcolors{ event2plot(index) }, ...
                          'linestyle', g.eventstyle { event2plot(index) }, ...
                          'linewidth', g.eventwidths( event2plot(index) ) );
    
            % schtefan: add Event types text above event latency line
            % -------------------------------------------------------
            EVENTFONT = ' \fontsize{10} ';
            evntxt = strrep(num2str(g.events(event2plot(index)).type),'_','-');
            if length(evntxt)>MAXEVENTSTRING, evntxt = [ evntxt(1:MAXEVENTSTRING-1) '...' ]; end; % truncate
            try
                tmph2 = text([tmplat], ylims(2)-0.005, [EVENTFONT evntxt], ...
                                    'color', g.eventcolors{ event2plot(index) }, ...
                                    'horizontalalignment', 'left',...
                                    'rotation',90);
            catch
                % Do nothing
            end;
            
            % draw duration is not 0
            % ----------------------
            if g.ploteventdur & ~isempty(g.eventlatencyend) ...
                    & g.eventwidths( event2plot(index) ) ~= 2.5 % do not plot length of boundary events
                tmplatend = g.eventlatencyend(event2plot(index))-lowlim-1;
                if tmplatend ~= 0, 
                    tmplim = ylim;
                    tmpcol = g.eventcolors{ event2plot(index) };
                    h = patch([ tmplat tmplatend tmplatend tmplat ], ...
                              [ tmplim(1) tmplim(1) tmplim(2) tmplim(2) ], ...
                              tmpcol );  % this argument is color
                    set(h, 'EdgeColor', 'none') 
                end;
            end;
         end;
    end;

    if g.trialstag(1) ~= -1
        
        % plot trial limits
        % -----------------
        tmptag = [lowlim:highlim];
       	tmpind = find(mod(tmptag-1, g.trialstag) == 0);
        for index = tmpind
            plot([tmptag(index)-lowlim-1 tmptag(index)-lowlim-1], [0 1], 'b--');
        end;
        alltag = tmptag(tmpind);

        % compute Xticks
        % --------------
        tagnum = (alltag-1)/g.trialstag+1;
     	set(g.ax0,'XTickLabel', tagnum,'YTickLabel', [],...
		'Xlim',[0 g.winlength*multiplier],...
		'XTick',alltag-lowlim+g.trialstag/2, 'YTick',[], 'tag','backeeg');
		
		axes(g.ax1);
		tagpos  = [];
		tagtext = [];
		if ~isempty(alltag)
			alltag = [alltag(1)-g.trialstag alltag alltag(end)+g.trialstag]; % add border trial limits
		else
			alltag = [ floor(lowlim/g.trialstag)*g.trialstag ceil(highlim/g.trialstag)*g.trialstag ]+1;
		end;
        
		nbdiv = 20/g.winlength; % approximative number of divisions
		divpossible = [ 100000./[1 2 4 5] 10000./[1 2 4 5] 1000./[1 2 4 5] 100./[1 2 4 5 10 20]]; % possible increments
		[tmp indexdiv] = min(abs(nbdiv*divpossible-(g.limits(2)-g.limits(1)))); % closest possible increment

		incrementpoint = divpossible(indexdiv)/1000*g.srate;
        if g.limits(2) < 0, tagzerooffset  = (g.limits(2)-g.limits(1))/1000*g.srate+1; 
        else                tagzerooffset  = -g.limits(1)/1000*g.srate; 
        end;

		for i=1:length(alltag)-1
			if ~isempty(tagpos) & tagpos(end)-alltag(i)<2*incrementpoint/3
				tagpos  = tagpos(1:end-1);
			end;
			if ~isempty(g.freqlimits)
				tagpos  = [ tagpos linspace(alltag(i),alltag(i+1)-1, nbdiv) ];
			else
				if tagzerooffset ~= 0
					tmptagpos = [alltag(i)+tagzerooffset:-incrementpoint:alltag(i)];
				else
					tmptagpos = [];
				end;
				tagpos  = [ tagpos [tmptagpos(end:-1:2) alltag(i)+tagzerooffset:incrementpoint:(alltag(i+1)-1)]];
			end;
		end;
        % find corresponding epochs
        % -------------------------
        tagtext = eeg_point2lat(tagpos, floor((tagpos)/g.trialstag)+1, g.srate, g.limits, 1E-3);
        set(g.ax1,'XTickLabel', tagtext,'XTick', tagpos-lowlim);

			
    else
     	set(g.ax0,'XTickLabel', [],'YTickLabel', [],...
		'Xlim',[0 g.winlength*multiplier],...
		'XTick',[], 'YTick',[], 'tag','backeeg');

		axes(g.ax1);
    	set(g.ax1,'XTickLabel', num2str((g.time:DEFAULT_GRID_SPACING:g.time+g.winlength)'),...
		'XTick',[1:multiplier*DEFAULT_GRID_SPACING:g.winlength*multiplier+1])
    end;
    		
    % ordinates: even if all elec are plotted, some may be hidden
    set(g.ax1, 'ylim',[g.elecoffset*g.spacing (g.elecoffset+g.dispchans+1)*g.spacing] );
    
    axes(g.ax1)	

  case 'draws'
    % Redraw EEG and change scale

    marker_h=findobj('-regexp','tag','marker_*');delete(marker_h);
    mark_h=findobj('-regexp','tag','mark_*');delete(mark_h);
    text_h=findobj('-regexp','tag','text_*');delete(text_h);
        
    g = get(gcf,'UserData');  
    data = get(g.ax1, 'userdata');
    ESpacing = findobj('tag','ESpacing','parent',gcf);   % ui handle
    EPosition = findobj('tag','EPosition','parent',gcf); % ui handle
    if g.trialstag(1) == -1
        g.time    = str2num(get(EPosition,'string'));  
    else 
        g.time    = str2num(get(EPosition,'string'))-1;   
    end;        
    g.spacing = str2num(get(ESpacing,'string'));  
    
    orgspacing= g.spacing;
    if p1 == 1
      	g.spacing= g.spacing+ 0.1*orgspacing; % increase g.spacing(5%)
	elseif p1 == 2
		g.spacing= max(0,g.spacing-0.1*orgspacing); % decrease g.spacing(5%)
    end
    if round(g.spacing*100) == 0
        maxindex = min(10000, g.frames);  
        g.spacing = 0.01*max(max(data(:,1:maxindex),[],2),[],1)-min(min(data(:,1:maxindex),[],2),[],1);  % Set g.spacingto max/min data
    end;

    % update edit box
    % ---------------
    set(ESpacing,'string',num2str(g.spacing,4))  
    set(gcf, 'userdata', g);
    set(g.ax1,'YLim',[0 (g.chans+1)*g.spacing],'YTick',[0:g.spacing:g.chans*g.spacing])
    set(g.ax1, 'ylim',[g.elecoffset*g.spacing (g.elecoffset+g.dispchans+1)*g.spacing] );
    
    ve_eegplot('drawp', 0);
    
    % update scaling eye (I) if it exists
    % -----------------------------------
    eyeaxes = findobj('tag','eyeaxes','parent',gcf);
    if ~isempty(eyeaxes)
      eyetext = findobj('type','text','parent',eyeaxes,'tag','thescalenum');
      set(eyetext,'string',num2str(g.spacing,4))
    end
    
    return;

  case 'window'  % change window size
    % get new window length with dialog box
    % -------------------------------------
    g = get(gcf,'UserData');
	result       = inputdlg2( { fastif(g.trialstag==-1,'New window length (s):', 'Number of epoch(s):') }, 'Change window length', 1,  { num2str(g.winlength) });
	if size(result,1) == 0 return; end;

	g.winlength = eval(result{1}); 
	set(gcf, 'UserData', g);

    % delete mark labels
    text_h=findobj('-regexp','tag','text_*');delete(text_h);
    marker_h=findobj('-regexp','tag','marker_*');delete(marker_h);

    ve_eegplot('drawp',0);    
	return;
    
  case 'winelec'  % change channel window size
                  % get new window length with dialog box
                  % -------------------------------------
   fig = gcf;
   g = get(gcf,'UserData');
   result = inputdlg2( ...
{ 'Number of channels to display:' } , 'Change number of channels to display', 1,  { num2str(g.dispchans) });
   if size(result,1) == 0 
       return;
   end;
   
   g.dispchans = eval(result{1});
   if g.dispchans<0 || g.dispchans>g.chans
       g.dispchans = g.chans;
   end;
   set(gcf, 'UserData', g);
   ve_eegplot('updateslider', fig);
   ve_eegplot('drawp',0);	
   ve_eegplot('scaleeye', [], fig);
   return;
   
  case 'loadelect' % load channels
	[inputname,inputpath] = uigetfile('*','Channel locations file');
	if inputname == 0 return; end;
	if ~exist([ inputpath inputname ])
		error('no such file');
	end;

	AXH0 = findobj('tag','eegaxis','parent',gcf);
	ve_eegplot('setelect',[ inputpath inputname ],AXH0);
	return;
  
  case 'setelect'
    % Set channels    
    eloc_file = p1;
    axeshand = p2;
    outvar1 = 1;
    if isempty(eloc_file)
      outvar1 = 0;
      return
    end
    
    tmplocs = readlocs(eloc_file);
	YLabels = { tmplocs.labels };
    YLabels = strvcat(YLabels);
    
    YLabels = flipud(str2mat(YLabels,' '));
    set(axeshand,'YTickLabel',YLabels)
  
  case 'title'
    % Get new title
	h = findobj('tag', 'eegplottitle');
	
	if ~isempty(h)
		result       = inputdlg2( { 'New title:' }, 'Change title', 1,  { get(h(1), 'string') });
		if ~isempty(result), set(h, 'string', result{1}); end;
	else 
		result       = inputdlg2( { 'New title:' }, 'Change title', 1,  { '' });
		if ~isempty(result), h = textsc(result{1}, 'title'); set(h, 'tag', 'eegplottitle');end;
	end;
	
	return;

  case 'scaleeye'
    % Turn scale I on/off
    obj = p1;
    figh = p2;
	g = get(figh,'UserData');
    % figh = get(obj,'Parent');

    if ~isempty(obj)
		eyeaxes = findobj('tag','eyeaxes','parent',figh);
		children = get(eyeaxes,'children');
		if isstr(obj)
			if strcmp(obj, 'off')
				set(children, 'visible', 'off');
				set(eyeaxes, 'visible', 'off');
				return;
			else
				set(children, 'visible', 'on');
				set(eyeaxes, 'visible', 'on');
			end;
		else
			toggle = get(obj,'checked');
			if strcmp(toggle,'on')
				set(children, 'visible', 'off');
				set(eyeaxes, 'visible', 'off');
				set(obj,'checked','off');
				return;
			else
				set(children, 'visible', 'on');
				set(eyeaxes, 'visible', 'on');
				set(obj,'checked','on');
			end;
		end;
	end;
	
	eyeaxes = findobj('tag','eyeaxes','parent',figh);
	YLim = get(g.ax1, 'ylim');
    
	ESpacing = findobj('tag','ESpacing','parent',figh);
	g.spacing= str2num(get(ESpacing,'string'));
	
	axes(eyeaxes); cla; axis off;
    set(eyeaxes, 'ylim', YLim);
    
	Xl = [.35 .65; .5 .5; .35 .65];
    Yl = [ g.spacing g.spacing; g.spacing 0; 0 0] + YLim(1);
	plot(Xl(1,:),Yl(1,:),'color',DEFAULT_AXIS_COLOR,'clipping','off', 'tag','eyeline'); hold on;
	plot(Xl(2,:),Yl(2,:),'color',DEFAULT_AXIS_COLOR,'clipping','off', 'tag','eyeline');
	plot(Xl(3,:),Yl(3,:),'color',DEFAULT_AXIS_COLOR,'clipping','off', 'tag','eyeline');
	text(.5,(YLim(2)-YLim(1))/23+Yl(1),num2str(g.spacing,4),...
		 'HorizontalAlignment','center','FontSize',10,...
		 'tag','thescalenum')
    text(Xl(2)+.1,Yl(1),'+','HorizontalAlignment','left',...
         'verticalalignment','middle', 'tag', 'thescale')
    text(Xl(2)+.1,Yl(4),'-','HorizontalAlignment','left',...
         'verticalalignment','middle', 'tag', 'thescale')
	if ~isempty(SPACING_UNITS_STRING)
         text(.5,-YLim(2)/23+Yl(4),SPACING_UNITS_STRING,...
			 'HorizontalAlignment','center','FontSize',10, 'tag', 'thescale')
	end
	text(.5,(YLim(2)-YLim(1))/10+Yl(1),'Scale',...
		 'HorizontalAlignment','center','FontSize',10, 'tag', 'thescale')
    set(eyeaxes, 'tag', 'eyeaxes');
    
  case 'noui'
      dbstop in ve_eegplot.m at 1774;
      if ~isempty(varargin)
          ve_eegplot( varargin{:} ); fig = gcf;
      else 
          fig = findobj('tag', 'EEGPLOT');
      end;
      set(fig, 'menubar', 'figure');
      
      % find button and text
      obj = findobj(fig, 'style', 'pushbutton'); delete(obj);
      obj = findobj(fig, 'style', 'edit'); delete(obj);
      obj = findobj(fig, 'style', 'text'); 
      %objscale = findobj(obj, 'tag', 'thescale');
      %delete(setdiff(obj, objscale));
	  obj = findobj(fig, 'tag', 'Eelec');delete(obj);
	  obj = findobj(fig, 'tag', 'Etime');delete(obj);
	  obj = findobj(fig, 'tag', 'Evalue');delete(obj);
	  obj = findobj(fig, 'tag', 'Eelecname');delete(obj);
	  obj = findobj(fig, 'tag', 'Etimename');delete(obj);
	  obj = findobj(fig, 'tag', 'Evaluename');delete(obj);
	  obj = findobj(fig, 'type', 'uimenu');delete(obj);
 
   case 'zoom' % if zoom
      g = get(gcf,'UserData'); 
      fig = varargin{1};
      tmpxlim  = get(g.ax1, 'xlim');
      tmpylim  = get(g.ax1, 'ylim');
      tmpxlim2 = get(g.ax0, 'xlim');
      set(g.ax0, 'xlim', get(g.ax1, 'xlim'));
      
      % deal with abscissa
      % ------------------
      if g.trialstag ~= -1
          Eposition = str2num(get(findobj('tag','EPosition','parent',fig), 'string'));
          g.winlength = (tmpxlim(2) - tmpxlim(1))/g.trialstag;
          Eposition = Eposition + (tmpxlim(1) - tmpxlim2(1)-1)/g.trialstag;
          Eposition = round(Eposition*1000)/1000;
          set(findobj('tag','EPosition','parent',fig), 'string', num2str(Eposition));
      else
          Eposition = str2num(get(findobj('tag','EPosition','parent',fig), 'string'))-1;
          g.winlength = (tmpxlim(2) - tmpxlim(1))/g.srate;	
          Eposition = Eposition + (tmpxlim(1) - tmpxlim2(1)-1)/g.srate;
          Eposition = round(Eposition*1000)/1000;
          set(findobj('tag','EPosition','parent',fig), 'string', num2str(Eposition+1));
      end;  
      
      % deal with ordinate
      % ------------------
      g.elecoffset = tmpylim(1)/g.spacing;
      g.dispchans  = round(1000*(tmpylim(2)-tmpylim(1))/g.spacing)/1000;      
      
      set(fig,'UserData', g);
      ve_eegplot('updateslider', fig);
      ve_eegplot('drawp', 0);
      ve_eegplot('scaleeye', [], fig);

      % reactivate zoom if 3 arguments
      % ------------------------------
      if exist('p2') == 1
          set(gcbf, 'windowbuttondownfcn', [ 'zoom(gcbf,''down''); ve_eegplot(''zoom'', gcbf, 1);' ]);
          set(gcbf, 'windowbuttonmotionfcn', g.commandselect{2});
      end;

	case 'updateslider' % if zoom
      fig = varargin{1};
      g = get(fig,'UserData');
      sliider = findobj('tag','eegslider','parent',fig);
      if g.elecoffset < 0
         g.elecoffset = 0;
      end;
      if g.dispchans >= g.chans
         g.dispchans = g.chans;
         g.elecoffset = 0;
         set(sliider, 'visible', 'off');
      else
         set(sliider, 'visible', 'on');         
		 set(sliider, 'value', g.elecoffset/g.chans, ...
					  'sliderstep', [1/(g.chans-g.dispchans) g.dispchans/(g.chans-g.dispchans)]);
         %'sliderstep', [1/(g.chans-1) g.dispchans/(g.chans-1)]);
      end;
      if g.elecoffset < 0
         g.elecoffset = 0;
      end;
      if g.elecoffset > g.chans-g.dispchans
         g.elecoffset = g.chans-g.dispchans;
      end;
      set(fig,'UserData', g);
	  ve_eegplot('scaleeye', [], fig);
   
   case 'drawlegend'
      fig = varargin{1};
      g = get(fig,'UserData');
      
      if ~isempty(g.events) % draw vertical colored lines for events, add event name text above
          nleg = length(g.eventtypes);
          fig2 = figure('numbertitle', 'off', 'name', '', 'visible', 'off', 'menubar', 'none', 'color', DEFAULT_FIG_COLOR);
          pos = get(fig2, 'position');
          set(fig2, 'position', [ pos(1) pos(2) 130 14*nleg+20]);
          
          for index = 1:nleg
              plot([10 30], [(index-0.5) * 10 (index-0.5) * 10], 'color', g.eventtypecolors{index}, 'linestyle', ...
                          g.eventtypestyle{ index }, 'linewidth', g.eventtypewidths( index )); hold on;
              if iscell(g.eventtypes)
                  th=text(35, (index-0.5)*10, g.eventtypes{index}, ...
                                    'color', g.eventtypecolors{index});
              else
                  th=text(35, (index-0.5)*10, num2str(g.eventtypes(index)), ...
                                    'color', g.eventtypecolors{index});
              end;
          end;
          xlim([0 130]);
          ylim([0 nleg*10]);
          axis off;
          set(fig2, 'visible', 'on');
      end;


  % motion button: move windows or display current position (channel, g.time and activation)
  % ----------------------------------------------------------------------------------------
  case 'defmotioncom'
    fig = varargin{1};
    g = get(fig,'UserData');

	tmppos = get(g.ax0, 'currentpoint');

    if g.trialstag ~= -1,
        lowlim = round(g.time*g.trialstag+1);
    else
        lowlim = round(g.time*g.srate+1);
    end;
    if g.incallback
        g.winrej = [g.winrej(1:end-1,:)' [g.winrej(end,1) tmppos(1)+lowlim g.winrej(end,3:end)]']';
        set(fig,'UserData', g);
        ve_eegplot('drawb');
    else
        g.etime = findobj('tag','Etime','parent',fig);
        tmppos = get(g.ax1, 'currentpoint');
        xlims=get(g.ax1,'XLim');
        ylims=get(g.ax1,'YLim');
        global on_data_ax;
        if (tmppos(1,1)>xlims(1)&&tmppos(1,1)<xlims(2))&& ...
                (tmppos(1,2)>ylims(1)&&tmppos(1,2)<ylims(2))
            if strcmp(g.mouse_data_front,'on')
                figure(gcbf);
            end
            if isempty(on_data_ax)
                esh=findobj('tag','ESpacing','parent',gcbf);
                
                set(esh,'enable','off');
                drawnow;
                set(esh,'enable','on');
                
                eph=findobj('tag','EPosition','parent',gcbf);
                set(eph,'enable','off');drawnow;set(eph,'enable','on');
                on_data_ax=1;
            end
            if g.trialstag ~= -1,
                set(g.etime, 'string', num2str(mod(tmppos(1)+lowlim-1,g.trialstag)/g.trialstag*(g.limits(2)-g.limits(1)) + g.limits(1)));
            else set(g.etime, 'string', num2str((tmppos(1)+lowlim-1)/g.srate)); % put g.time in the box
            end;
            if (tmppos(1,1)<xlims(1)||tmppos(1,1)>xlims(2))|| ...
                    (tmppos(1,2)<ylims(1)||tmppos(1,2)>ylims(2))
                if ~isempty(on_data_ax);clear global on_data_ax;end
            end
            tmpelec = round(tmppos(1,2) / g.spacing);
            tmpelec = min(max(double(tmpelec), 1),g.chans);
            labls = get(g.ax1, 'YtickLabel');
            g.eelec = findobj('tag','Eelec','parent',fig);  % put electrode in the box
            if ~g.envelope
                set(g.eelec, 'string', labls(tmpelec+1,:));
            else
                set(g.eelec, 'string', ' ');
            end
            g.evalue = findobj('tag','Evalue','parent',fig);
            if ~g.envelope
                eegplotdata = get(g.ax1, 'userdata');
                set(g.evalue, 'string', num2str(eegplotdata(g.chans+1-tmpelec, min(g.frames,max(1,double(round(tmppos(1)+lowlim)))))));  % put value in the box
            else
                set(g.evalue,'string',' ');
            end
        end
    end;
         
  % add topoplot
  % ------------
  case 'topoplot'
    fig = varargin{1};
    g = get(fig,'UserData');
    if ~isstruct(g.eloc_file) || ~isfield(g.eloc_file, 'theta') || isempty( [ g.eloc_file.theta ])
        return;
    end;
    tmppos = get(g.ax0, 'currentpoint');
    
    % plot vertical line
    yl = ylim;
    plot([ tmppos tmppos ], yl, 'color', [0.8 0.8 0.8]);
    
    if g.trialstag ~= -1,
          lowlim = round(g.time*g.trialstag+1);
    else, lowlim = round(g.time*g.srate+1);
    end;
    data = get(g.ax1,'UserData');
    datapos = max(1, round(tmppos(1)+lowlim));
    datapos = min(datapos, g.frames);

    figure; topoplot(data(:,datapos), g.eloc_file);
    if g.trialstag == -1,
         latsec = (datapos-1)/g.srate;
         title(sprintf('Latency of %d seconds and %d milliseconds', floor(latsec), round(1000*(latsec-floor(latsec)))));
    else
        trial = ceil((datapos-1)/g.trialstag);
        
        latintrial = eeg_point2lat(datapos, trial, g.srate, g.limits, 0.001);
        title(sprintf('Latency of %d ms in trial %d', round(latintrial), trial));
    end;
    return;
    
  % release button: check window consistency, add to trial boundaries
  % -------------------------------------------------------------------
  case 'defupcom'
    fig = varargin{1};
    g = get(fig,'UserData');
    g.incallback = 0;
    set(fig,'UserData', g);  % early save in case of bug in the following
    if strcmp(g.mocap,'on'), g.winrej = g.winrej(end,:);end; % nima
    if ~isempty(g.winrej)', ...
        if g.winrej(end,1) == g.winrej(end,2) % remove unitary windows
            g.winrej = g.winrej(1:end-1,:);
        else
            if g.winrej(end,1) > g.winrej(end,2) % reverse values if necessary
                g.winrej(end, 1:2) = [g.winrej(end,2) g.winrej(end,1)];
            end;
            g.winrej(end,1) = max(1, g.winrej(end,1));
            g.winrej(end,2) = min(g.frames, g.winrej(end,2));
            if g.trialstag == -1 % find nearest trials boundaries if necessary
                I1 = find((g.winrej(end,1) >= g.winrej(1:end-1,1)) & (g.winrej(end,1) <= g.winrej(1:end-1,2)) ); 
                if ~isempty(I1)
                    g.winrej(I1,2) = max(g.winrej(I1,2), g.winrej(end,2)); % extend epoch
                    g.winrej = g.winrej(1:end-1,:); % remove if empty match
                else,
                   I2 = find((g.winrej(end,2) >= g.winrej(1:end-1,1)) & (g.winrej(end,2) <= g.winrej(1:end-1,2)) ); 
                   if ~isempty(I2)
                        g.winrej(I2,1) = min(g.winrej(I2,1), g.winrej(end,1)); % extend epoch
                        g.winrej = g.winrej(1:end-1,:); % remove if empty match
                    else,
                       I2 = find((g.winrej(end,1) <= g.winrej(1:end-1,1)) & (g.winrej(end,2) >= g.winrej(1:end-1,1)) ); 
                       if ~isempty(I2)
                            g.winrej(I2,:) = []; % remove if empty match
                       end;
                    end;
                end;
            end;
        end;
    end;
    set(fig,'UserData', g);
    %ve_eegplot('drawp', 0);
    if strcmp(g.mocap,'on'), show_mocap_for_eegplot(g.winrej); g.winrej = g.winrej(end,:); end; % nima
            
  % push button: create/remove window
  % ---------------------------------
  case 'defdowncom'
    show_mocap_timer = timerfind('tag','mocapDisplayTimer'); if ~isempty(show_mocap_timer),  end; % nima
    fig = varargin{1};
    g = get(fig,'UserData');
    
    tmppos = get(g.ax0, 'currentpoint');
    if strcmp(get(fig, 'SelectionType'),'normal');
        g = get(fig,'UserData'); % get data of backgroung image {g.trialstag g.winrej incallback}
        if g.incallback ~= 1 % interception of nestest calls
            if g.trialstag ~= -1,
                lowlim = round(g.time*g.trialstag+1);
                highlim = round(g.winlength*g.trialstag);
            else,
                lowlim  = round(g.time*g.srate+1);
                highlim = round(g.winlength*g.srate);
            end;
            if (tmppos(1) >= 0) & (tmppos(1) <= highlim),
                if isempty(g.winrej) Allwin=0
                else Allwin = (g.winrej(:,1) < lowlim+tmppos(1)) & (g.winrej(:,2) > lowlim+tmppos(1));
                end;
                if any(Allwin) % remove the mark or select electrode if necessary
                    lowlim = find(Allwin==1);
                    if g.setelectrode  % select electrode  
                        tmppos = get(g.ax1, 'currentpoint');
                        tmpelec = g.chans + 1 - round(tmppos(1,2) / g.spacing);
                        tmpelec = min(max(tmpelec, 1), g.chans);
                        g.winrej(lowlim,tmpelec+5) = ~g.winrej(lowlim,tmpelec+5); % set the electrode
                    else  % remove mark
                        g.winrej(lowlim,:) = [];
                    end;
                else
                    if g.trialstag ~= -1 % find nearest trials boundaries if epoched data
                        alltrialtag = [0:g.trialstag:g.frames];
                        I1 = find(alltrialtag < (tmppos(1)+lowlim) ); 
                        if ~isempty(I1) & I1(end) ~= length(alltrialtag),
                            g.winrej = [g.winrej' [alltrialtag(I1(end)) alltrialtag(I1(end)+1) g.wincolor zeros(1,g.chans)]']';
                        end;
                    else,
    	                g.incallback = 1;  % set this variable for callback for continuous data
                        if size(g.winrej,2) < 5
                            g.winrej(:,3:5) = repmat(g.wincolor, [size(g.winrej,1) 1]);
                        end;
                        if size(g.winrej,2) < 5+g.chans
                            g.winrej(:,6:(5+g.chans)) = zeros(size(g.winrej,1),g.chans);
                        end;
                        g.winrej = [g.winrej' [tmppos(1)+lowlim tmppos(1)+lowlim g.wincolor zeros(1,g.chans)]']';
                    end;
                end;
                set(fig,'UserData', g);
                ve_eegplot('drawb', 0);  % redraw background
            end;
        end;
    end;      
   otherwise
      error(['Error - invalid ve_eegplot() parameter: ',data])
  end  
end
end


% function not supported under Mac
% --------------------------------
function [reshist, allbin] = myhistc(vals, intervals)

	reshist = zeros(1, length(intervals));
	allbin = zeros(1, length(vals));
	
	for index=1:length(vals)
		minvals = vals(index)-intervals;
		bintmp  = find(minvals >= 0);
		[mintmp indextmp] = min(minvals(bintmp));
		bintmp = bintmp(indextmp);
		
		allbin(index) = bintmp;
		reshist(bintmp) = reshist(bintmp)+1;
	end;
end
    
